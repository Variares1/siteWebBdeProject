<?php
function checkSignUp($array)

{


    $name = htmlspecialchars($_POST['name']);
    $firstName = htmlspecialchars($_POST['firstName']);
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);
    $confirmPassword = htmlspecialchars($_POST['confirmPassword']);

    $err0 = "not same password";
    $err1 = "7 char min";
    $err2 = "30 char max";
    $err3 = "email existe deja en BDD";
    $err4 = "password needs at least one uppercase and one number";
    $err5 = "special characters are not authorized";
    $err6 = "this person is already registered";

    $success = false;

    if($password == $confirmPassword){
        if (substr($password, 7)!= false){
            if (strlen($password, 30)!= false){
                if (strlen($password, 30)!= false){
                    if (/*$email n'existe pas en bdd*/){
                        if (/*$password n'a pas une maj et un chiffre*/){
                            if (/*$name a un caractère spécial*/){
                                if (/*$firstName a un caractère spécial*/){
                                    if (/*$email a un caractère spécial*/){
                                        if (/*$password a un caractère spécial*/){
                                            if (/*$confirmPassword a un caractère spécial*/){
                                                if (/*$name & firstName existe déja en bdd*/){
                                                    $success = true;


                                                }
                                                else return $err6;
                                            }
                                            else return $err5;
                                        }
                                        else return $err5;
                                    }
                                    else return $err5;
                                }
                                else return $err5;
                            }
                            else return $err5;
                        }
                        else return $err4;
                    }
                    else return $err3;
                }
                else return $err2;
            }
            else return $err2;
        }
        else return $err1;
    }
    else return $err0;

}

header('Location: http://localhost/siteWebBdeProject/views/viewSign.html.php');
