<?php require_once('header.inc.php') ?>

    <div class="container-page">
        <div class="events">
            <h1>EVENTS <br><p>Our last activities !</p></h1>
        </div>
    </div>

<?php require_once('footer.inc.php') ?>