<?php

$email = htmlspecialchars($_POST['email']);
$password = htmlspecialchars($_POST['password']);

