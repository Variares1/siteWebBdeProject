<?php require_once('header.inc.php') ?>

    <div class="container-page">
        <div class="ideas">
            <h1>
                IDEAS BOX
                <br>
                <p>Your purposes, your votes, your project : our project !</p>
            </h1>
        </div>
    </div>

<?php require_once('footer.inc.php') ?>