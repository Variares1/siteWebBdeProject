

    <div class="container-page">
        <div class="events">
            <h1>EVENTS <br><p>Our last activities !</p></h1>
        </div>
        <div class="change-event">
            <!-- <img src="D:\EXIA\A2\prosit 2.4\site\assets\img\logo2.png" alt="logo" class="logo"/>
     -->
            <ul>

                <button> <a href = "http://localhost/siteWebBdeProject/admin/viewIdeasA.html.php">Créer</a></button>
                <input type="button" value="Modifier" onclick="">
                <input type="button" value="Supprimer" onclick="">

            </ul>
    </div>

