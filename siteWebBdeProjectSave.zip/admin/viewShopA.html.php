<?php require_once('header.inc.php') ?>

    <div class="container-page">
        <div class="shop">
            <h1>SHOP <br><p>Our goodies</p></h1>
        </div>
    </div>

<?php require_once('footer.inc.php') ?>